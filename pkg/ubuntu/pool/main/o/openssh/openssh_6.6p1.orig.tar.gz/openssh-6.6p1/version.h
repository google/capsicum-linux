/* $OpenBSD: version.h,v 1.70 2014/02/27 22:57:40 djm Exp $ */

#define SSH_VERSION	"OpenSSH_6.6"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
