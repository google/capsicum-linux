// Copyright (c) 2010 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint64_t uint64;
#define HAVE_SYMBOLIZE 1
#define ATTRIBUTE_NOINLINE __attribute__ ((noinline))
